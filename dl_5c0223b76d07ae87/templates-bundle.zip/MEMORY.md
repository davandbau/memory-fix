# MEMORY.md — Second Brain Index

<!--
  This is the map to your memory system. It tells your AI where everything
  lives and how the pieces connect.
  
  The actual instructions for using memory are in AGENTS.md.
  This file is the reference card.
-->

## File Layout

| File | Purpose |
|------|---------|
| `AGENTS.md` | Boot sequence — tells AI what to do every session |
| `SOUL.md` | Identity and personality |
| `IDENTITY.md` | Name, emoji, avatar (read by OpenClaw for display) |
| `USER.md` | Context about you (timezone, preferences, etc.) |
| `HEARTBEAT.md` | Proactive check-in configuration |
| `memory/PROJECTS.md` | Active projects with priorities and next actions |
| `memory/AREAS.md` | Ongoing responsibilities (no end date) |
| `memory/RESOURCES.md` | Reference knowledge organized by topic |
| `memory/ARCHIVE.md` | Completed projects, retired info |
| `memory/inbox.md` | Quick capture buffer (processed by heartbeats + nightly review) |
| `memory/daily/YYYY-MM-DD.md` | Daily structured logs |

## Priority System

- 🔴 **P1:** Urgent + Important (blocking, time-sensitive — max 3 at a time)
- 🟡 **P2:** Important, not urgent (strategic)
- 🟢 **P3:** Nice to have
- ⚪ **P4:** Someday / maybe

## How It All Connects

```
Session starts → AI reads AGENTS.md
                 → reads SOUL.md, USER.md, PROJECTS.md, daily notes
                 → picks up where you left off

During conversation → captures to inbox.md or directly to PARA files

Heartbeat (every ~30 min) → processes inbox
                           → checks project health
                           → maintains daily note

Nightly review (cron) → reads full transcript
                       → updates daily note
                       → deep-processes inbox
                       → archives completed work
                       → flags items for tomorrow
```

---

_This file rarely needs editing. Update it if you add new memory files or change the structure._

# USER.md — About Your Human

<!--
  Tell your bot who you are. The more context here, the better it can help.
  Start with the basics. Add detail over time.
  
  Remember: you're teaching a colleague about yourself, 
  not building a surveillance dossier. Keep it respectful and relevant.
-->

- **Name:** <!-- Your name -->
- **What to call you:** <!-- Nickname, first name, etc. -->
- **Pronouns:** <!-- Optional -->
- **Timezone:** <!-- e.g., America/New_York, Europe/London -->

## What I Do

<!-- 
  Your role, company, industry. What fills your days?
  Example: "CEO of a SaaS startup. 12-person team. Series A. 
  Mostly doing sales, hiring, and product strategy right now."
-->

## What I Care About

<!--
  Projects, interests, goals. What should your bot pay attention to?
  Example: "Building in public on Twitter. Learning to invest. 
  Training for a half marathon. Obsessed with productivity systems."
-->

## Communication Preferences

<!--
  How do you like to interact? Examples:
  - "Keep messages short. I skim."
  - "Give me options, not just one answer."  
  - "Don't sugarcoat bad news."
  - "I prefer bullet points over paragraphs."
-->

## Key People

<!--
  Important contacts your bot should know about.
  Example:
  - Sarah — co-founder, handles product
  - Marcus — investor, monthly check-ins
  - Mom — her birthday is March 12
-->

## Notes

<!--
  Anything else relevant. Grows over time.
  Your bot (or the nightly review) can suggest additions here.
-->

---

_The more you share, the better your bot can help. Update this as you go._

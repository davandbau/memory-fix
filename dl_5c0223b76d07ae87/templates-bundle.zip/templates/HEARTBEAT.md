# HEARTBEAT.md — Proactive Check-In Configuration

<!--
  Heartbeats let your bot check on things periodically without you asking.
  Configure what it should look at during each heartbeat poll.
  
  Keep this lean — each check costs tokens. 2-4 items is ideal.
  The bot checks these every ~30 minutes (configurable on your platform).
-->

## Checks

<!--
  Uncomment and customize the checks you want.
  Remove or comment out the ones you don't need.
-->

<!-- - [ ] Any urgent unread emails in the last 2 hours? -->
<!-- - [ ] Calendar events in the next 4 hours? -->
<!-- - [ ] Any failing cron jobs or system errors? -->
<!-- - [ ] Check Twitter/social notifications? -->

## Rules

- **Quiet hours:** 23:00–08:00 — don't alert unless truly urgent
- **If nothing to report:** Reply `HEARTBEAT_OK`
- **Don't over-notify:** Only reach out if there's something actionable

<!--
  Advanced: Track check timestamps in memory/heartbeat-state.json
  to avoid redundant checks:
  
  {
    "lastChecks": {
      "email": 1703275200,
      "calendar": 1703260800
    }
  }
-->

# MEMORY.md — Second Brain Index

<!--
  This file is the MAP of your memory system.
  Your bot reads this to understand how memory works — the structure, the process, the rules.
  You shouldn't need to edit this often. The actual content lives in the memory/ files.
-->

## File Map

| File | Purpose |
|------|---------|
| `memory/PROJECTS.md` | Active projects with priorities, status, next actions |
| `memory/AREAS.md` | Ongoing responsibilities (no end date) |
| `memory/RESOURCES.md` | Reference knowledge organized by topic |
| `memory/ARCHIVE.md` | Completed projects, retired info |
| `memory/inbox.md` | Quick capture buffer (processed nightly) |
| `memory/daily/YYYY-MM-DD.md` | Daily structured logs |

## How It Works

### Capture (During Conversations)
- Important facts, decisions, action items → `memory/inbox.md`
- If it clearly belongs somewhere → write directly to the right PARA file
- When in doubt, inbox it. The nightly review will sort it.

### Nightly Review (Automated)
1. Reads the full day's conversations
2. Writes/updates the structured daily note
3. Processes inbox → routes items to Projects/Areas/Resources
4. Updates project statuses and next actions
5. Archives completed items
6. Flags items needing attention tomorrow

### Priority System
- 🔴 P1: Urgent + Important (blocking, time-sensitive) — max 3 at a time
- 🟡 P2: Important, not urgent (strategic work)
- 🟢 P3: Nice to have (do if time allows)
- ⚪ P4: Someday/maybe (review monthly — promote or archive)

## Session Startup Checklist
1. Read `SOUL.md` and `USER.md`
2. Read `memory/PROJECTS.md`
3. Read today + yesterday's daily notes
4. Read `memory/AREAS.md` and `memory/RESOURCES.md` as needed

# Inbox — Quick Capture

<!--
  Dump things here during conversations. Don't worry about organization.
  The nightly review processes this and routes items to the right PARA file.
  
  Format: just write it. Date-stamp if you want. Keep it fast.
  
  Examples:
  - 2026-02-24: David mentioned wanting to switch email providers — research options
  - 2026-02-24: New API endpoint for the dashboard: /api/v2/portfolio
  - 2026-02-24: Book recommendation from Marcus: "The Almanack of Naval Ravikant"
-->

---

<!-- New items go above this line. Nightly review clears processed items. -->

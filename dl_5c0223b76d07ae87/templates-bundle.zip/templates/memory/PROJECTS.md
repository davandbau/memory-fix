# PROJECTS.md — Active Projects

<!--
  Every active project lives here. When a project is done, move it to ARCHIVE.md.
  
  Priority levels:
  🔴 P1: Urgent + Important (max 3 at a time)
  🟡 P2: Important, not urgent
  🟢 P3: Nice to have
  ⚪ P4: Someday/maybe
  
  Each project needs: priority, status, next action, and enough context
  that future-you (or your bot) can pick it up cold.
-->

## 🔴 P1: Example — Launch Product Website
- **Status:** In Progress
- **Deadline:** March 15, 2026
- **Next Action:** Review designer's homepage mockups
- **Context:** Migrating from WordPress to Astro. Designer is Sarah. Domain already purchased. Hosting on Vercel.

<!-- 
## 🟡 P2: Your Next Project
- **Status:** Not Started | In Progress | Blocked | Done
- **Deadline:** 
- **Next Action:** 
- **Context:** 
-->

## ⚪ P4: Example — Learn Rust
- **Status:** Not Started
- **Deadline:** None
- **Next Action:** Find a good beginner tutorial
- **Context:** Interested in systems programming. Low priority — revisit monthly.

---

_Review P4 items monthly. Promote what's become important. Archive what's lost its spark._

# RESOURCES.md — Reference Knowledge

<!--
  Organized by topic. This is where your bot stores things it learns 
  that aren't tied to a specific project or area.
  
  Think of this as a personal wiki. Add sections as topics emerge.
  If a section gets too long (50+ lines), consider splitting it into its own file.
-->

## Preferences & Decisions

<!--
  Record decisions so you don't re-debate them.
  Example:
  - Chose Astro over Next.js for static sites (Feb 2026) — faster builds, simpler
  - Email provider: Fastmail (switched from Gmail, Jan 2026)
  - Preferred writing tone: direct, casual, no corporate speak
-->

## Key Contacts

<!--
  People your bot should know about.
  Example:
  - Sarah Chen — designer, available Tue/Thu, prefers Figma
  - Marcus — investor, quarterly check-ins, likes concise updates
-->

## Lessons Learned

<!--
  What you've figured out the hard way. Future-you will thank you.
  Example:
  - Don't schedule tweets before 9 AM — low engagement
  - Always test cron jobs manually before relying on them
  - When David says "quick question" it's never quick — block 30 min
-->

## Technical Notes

<!--
  Technical knowledge, API details, configuration notes.
  Example:
  - Stripe API key location: 1Password → Dev vault
  - Production deploy: `git push origin main` triggers Vercel auto-deploy
  - Database backups run at 03:00 UTC daily
-->

---

_This file grows over time. The nightly review may suggest additions._

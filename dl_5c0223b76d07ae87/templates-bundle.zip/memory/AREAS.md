# AREAS.md — Ongoing Responsibilities

<!--
  Areas are things you maintain but never "complete."
  Unlike projects, they don't have deadlines — they have standards.
  
  Examples: Health, Finances, a Client Relationship, Home Lab, Content Creation
  
  Keep each area brief. Link to RESOURCES.md for detailed reference info.
-->

## Communications
<!-- Email, social media, messaging — how you stay in touch -->
- **Standard:** Inbox zero daily. Respond within 24h.
- **Current status:** <!-- e.g., "Clean" or "47 unread, need to triage" -->

## Workspace & Tools
<!-- Your AI setup, dev environment, productivity tools -->
- **Standard:** Memory system maintained. Cron jobs healthy.
- **Current status:** <!-- e.g., "All systems green" -->

<!--
## Health & Fitness
- **Standard:** 
- **Current status:** 

## Finances
- **Standard:** 
- **Current status:** 

## [Your Area Here]
- **Standard:** 
- **Current status:** 
-->

---

_Add areas as they become relevant. Remove what you stop caring about._

# HEARTBEAT.md — Proactive Check-In Configuration

<!--
  Heartbeats let your AI check on things periodically without you asking.
  OpenClaw polls this every ~30 minutes (configurable).
  
  The memory maintenance section below is active by default — it's what
  keeps your memory system healthy between sessions.
  
  Add your own checks below as you integrate more tools (email, calendar, etc).
-->

## 🌙 Quiet Hours
- Between 23:00 and 08:00 (your timezone): reply HEARTBEAT_OK immediately
- Exception: truly urgent items (use your judgment)

## 🧠 Memory Maintenance (Every Heartbeat)

### Inbox Processing
- Read `memory/inbox.md`
- If items exist: route each to the correct PARA file
  - Task with a deadline → `memory/PROJECTS.md`
  - Ongoing responsibility → `memory/AREAS.md`
  - Reference info or lesson learned → `memory/RESOURCES.md`
- Clear processed items from inbox
- If an item is ambiguous, leave it and ask your human next time you chat

### Project Health
- Scan `memory/PROJECTS.md`
- Any P1/P2 project with no update in 3+ days → nudge your human
- Any project with all tasks checked → move to `memory/ARCHIVE.md`
- Any "Blocked" project → check if the blocker might be resolved

### Daily Note
- If `memory/daily/YYYY-MM-DD.md` doesn't exist for today → create it
- Append any significant decisions, outcomes, or context from recent conversations
- Don't wait for the nightly review — capture while it's fresh

### Memory Coherence
- Do PROJECTS.md entries still match reality?
- Are there duplicates between inbox and PROJECTS?
- Any RESOURCES.md sections referencing completed/archived projects? Clean up.
- Check AREAS.md status fields — update if stale

## ✅ Optional Checks

<!--
  Uncomment and customize as you add integrations.
  Each check costs tokens — keep the list focused on what matters to you.
-->

<!-- - [ ] Any urgent unread emails in the last 2 hours? -->
<!-- - [ ] Calendar events in the next 4 hours? -->
<!-- - [ ] Any failing cron jobs or system errors? -->
<!-- - [ ] Check social media notifications? -->

## Rules

- **If nothing to report:** Reply `HEARTBEAT_OK`
- **Don't over-notify:** Only message your human if there's something actionable
- **Memory maintenance is silent:** Process inbox and update files without reporting unless something needs human input

<!--
  Track check timestamps in memory/heartbeat-state.json
  to avoid redundant work:
  
  {
    "lastChecks": {
      "inbox": 1703275200,
      "projects": 1703260800
    }
  }
-->
